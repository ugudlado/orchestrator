"""
ORC-63 T-5: RED tests for orchestrator_next.readiness — the shared DAG-walk
module (the single source of node readiness for dispatch.py and record.py).

Covers: effective_depends_on, is_node_ready, ready_nodes, next_ready_node,
and mark_node_status.
"""
from __future__ import annotations

import os
import sys

import yaml

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS_DIR = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
if _SCRIPTS_DIR not in sys.path:
    sys.path.insert(0, _SCRIPTS_DIR)


def _make_state(tmp_path, nodes, phase="main", extra=None):
    """Write a state.yaml with a `nodes`-shape workflow_plan and load it."""
    from orchestrator_next.parser import load_state
    data = {
        "change_id": "f",
        "phase": phase,
        "workflow_plan": {phase: {"nodes": nodes, "filtered": []}},
        "step_history": [],
    }
    if extra:
        data.update(extra)
    p = tmp_path / "state.yaml"
    p.write_text(yaml.dump(data))
    return load_state(str(p))


# ---------------------------------------------------------------------------
# effective_depends_on
# ---------------------------------------------------------------------------

def test_effective_depends_on_explicit_honored():
    """depends_on is read verbatim; absent means no dependencies."""
    from orchestrator_next.readiness import effective_depends_on
    nodes = [{"id": "a"}, {"id": "b"}, {"id": "c", "depends_on": ["a"]}]
    assert effective_depends_on(nodes, "a") == []
    assert effective_depends_on(nodes, "b") == []
    assert effective_depends_on(nodes, "c") == ["a"]


# ---------------------------------------------------------------------------
# is_node_ready
# ---------------------------------------------------------------------------

def test_is_node_ready_true_only_when_deps_completed(tmp_path):
    """A node is ready only when every effective dependency is completed."""
    from orchestrator_next.readiness import is_node_ready
    state = _make_state(tmp_path, [
        {"id": "a", "status": "completed"},
        {"id": "b", "status": "pending", "depends_on": ["a"]},
        {"id": "c", "status": "pending", "depends_on": ["b"]},
    ])
    assert is_node_ready(state, "b") is True   # dep a completed
    assert is_node_ready(state, "c") is False  # dep b not completed


def test_is_node_ready_false_for_completed_node(tmp_path):
    """A completed node is not itself 'ready' (nothing to dispatch)."""
    from orchestrator_next.readiness import is_node_ready
    state = _make_state(tmp_path, [
        {"id": "a", "status": "completed"},
        {"id": "b", "status": "pending"},
    ])
    assert is_node_ready(state, "a") is False


def test_stray_node_keys_ignored(tmp_path):
    """Unknown node keys (e.g. repeat_until left in pre-existing state files)
    do not affect readiness — the field was removed from the engine."""
    from orchestrator_next.readiness import is_node_ready
    state = _make_state(tmp_path, [
        {"id": "exec", "status": "completed", "repeat_until": "all_tasks_completed"},
        {"id": "review", "status": "pending"},
    ], extra={"repo_root": str(tmp_path)})
    assert is_node_ready(state, "review") is True


# ---------------------------------------------------------------------------
# ready_nodes / next_ready_node
# ---------------------------------------------------------------------------

def test_ready_nodes_declaration_order(tmp_path):
    """ready_nodes returns ready, not-completed nodes in declaration order."""
    from orchestrator_next.readiness import ready_nodes
    state = _make_state(tmp_path, [
        {"id": "a", "status": "completed"},
        {"id": "b", "status": "pending"},
        {"id": "c", "status": "pending", "depends_on": ["b"]},
    ])
    # only b is ready (c depends on b)
    assert ready_nodes(state) == ["b"]


def test_next_ready_node_first_or_none(tmp_path):
    """next_ready_node returns ready_nodes[0], or None when phase complete."""
    from orchestrator_next.readiness import next_ready_node
    state = _make_state(tmp_path, [
        {"id": "a", "status": "completed"},
        {"id": "b", "status": "pending"},
    ])
    assert next_ready_node(state) == "b"
    done = _make_state(tmp_path, [
        {"id": "a", "status": "completed"},
        {"id": "b", "status": "completed"},
    ])
    assert next_ready_node(done) is None


# ---------------------------------------------------------------------------
# mark_node_status
# ---------------------------------------------------------------------------

def test_mark_node_status_flips_one_node(tmp_path):
    """mark_node_status flips exactly the named node's status in workflow_plan."""
    from orchestrator_next.readiness import mark_node_status
    state_raw = {
        "phase": "main",
        "workflow_plan": {"main": {"nodes": [
            {"id": "a", "status": "pending"},
            {"id": "b", "status": "pending"},
        ]}},
    }
    mark_node_status(state_raw, "main", "a", "in_progress")
    nodes = state_raw["workflow_plan"]["main"]["nodes"]
    assert nodes[0]["status"] == "in_progress"
    assert nodes[1]["status"] == "pending"


def test_readiness_module_imports():
    """The readiness module is importable (fails today — ModuleNotFoundError)."""
    import orchestrator_next.readiness  # noqa: F401


def test_plan_infers_completion_from_step_history(tmp_path):
    """Nodes with a completed step_history entry are not re-dispatched."""
    from orchestrator_next.parser import load_state
    from orchestrator_next.readiness import is_node_ready, next_ready_node

    state_path = tmp_path / "state.yaml"
    state_path.write_text(yaml.dump({
        "change_id": "done",
        "phase": "implement",
        "workflow_plan": {"implement": {"nodes": [{"id": "my-step", "depends_on": []}]}},
        "step_history": [{
            "step_id": "my-step",
            "phase": "implement",
            "status": "completed",
            "agent": "developer",
            "attempt": 1,
        }],
    }))
    state = load_state(str(state_path))
    assert is_node_ready(state, "my-step") is False
    assert next_ready_node(state) is None


def test_plan_advances_to_successor(tmp_path):
    """Dispatch advances to the next step after predecessor completes."""
    from orchestrator_next.parser import load_state
    from orchestrator_next.readiness import next_ready_node

    state_path = tmp_path / "state.yaml"
    state_path.write_text(yaml.dump({
        "change_id": "chain",
        "phase": "implement",
        "workflow_plan": {"implement": {"nodes": [
            {"id": "step-a", "depends_on": []},
            {"id": "step-b", "depends_on": ["step-a"]},
        ]}},
        "step_history": [{
            "step_id": "step-a",
            "phase": "implement",
            "status": "completed",
            "agent": None,
            "attempt": 1,
        }],
    }))
    state = load_state(str(state_path))
    assert next_ready_node(state) == "step-b"
