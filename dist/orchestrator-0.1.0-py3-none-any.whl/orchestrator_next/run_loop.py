"""In-process dispatch loop for `orchestrator run`.

Replaces the bash drivers (run-workflow.sh, orchestrator-run.sh, seed-state.sh's
shell glue). `orchestrator run <id>` drives every step in-process: dispatch →
execute (agent|script) → record → repeat. One canonical path per step kind.

Exit codes (protocol, unchanged):
  1 complete · 2 blocked · 3 contract/parse error · 4 unknown agent route ·
  6 tool subprocess failure (recorded) · 7 unexpected/usage.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml

from orchestrator_next import model_routes
from orchestrator_next.dispatch import ContractDispatchError, dispatch
# dispatch.py defines its own ContractDispatchError(RuntimeError); parser raises
# ContractNotFoundError(ValueError) for a missing script payload and
# ContractError(ValueError) for a malformed contract. Catch all three so any
# contract problem returns exit 3 instead of crashing the loop.
from orchestrator_next.parse_completion import parse_completion
from orchestrator_next.parser import ContractError, ContractNotFoundError, load_state
from orchestrator_next.pricing import format_cost_so_far, format_last_step_usage
from orchestrator_next.record import autocommit_state, record
from orchestrator_next.usage_adapters import ZEROED_USAGE, split_stdout

_COMPLETION_CONTRACT = """
---
You MUST end your stdout with a COMPLETION: block. Fields must be indented under COMPLETION: with two spaces — do NOT write them at column 0 and do NOT wrap in code fences.

IMPORTANT: Output values are parsed as YAML. If a value contains a colon (:), quote the entire value with double quotes.

On status completed/recovered, also emit an evidence: block under outputs: `verified` maps 1:1 to this step prompt's `## Verify` items (each a check you ran and its real result — never fabricated); `decisions` lists non-obvious choices made and why (may be empty for mechanical steps). Upgrade the one-line briefing to 2-4 sentences: what was done, how, and which evidence above supports it.

Success form:
COMPLETION:
  step_id: <this-step-id>
  status: completed
  outputs:
    key: value
    evidence:
      verified:
        - check: "<a ## Verify item, run verbatim>"
          result: "<real output>"
      decisions:
        - "<non-obvious choice and why>"
    briefing: >
      <what was done, how, and which evidence above supports it — 2-4 sentences>

Failure/skip form (no evidence required — the step did not complete):
COMPLETION:
  step_id: <this-step-id>
  status: abandoned
  outputs:
    reason: "why this step could not complete (quote if the reason contains a colon)"
    briefing: "<one-line summary of outcome>"
"""

# Zero floor overlaid under every recorded usage dict. Derived from the adapters'
# own constant rather than hand-copied: the two drifted before (this held
# cache_read_tokens/cache_creation_tokens, which no reader consumed, so the counts
# here stayed 0 next to the adapter's real ones). Token keys only — `model` is set
# per-payload and a failed step must not carry a `cost_usd`.
_EMPTY_USAGE = {k: 0 for k in ZEROED_USAGE if k.endswith("_tokens")}

def _ts() -> str:
    return datetime.now().strftime("%H:%M:%S")


def _log(msg: str) -> None:
    print(f"[{_ts()}] {msg}", file=sys.stderr)


def _log_cost_so_far(state_yaml_path: str) -> None:
    """Emit the step's own usage, then the running `[cost so far: $X.XX]` total,
    both re-derived from live state.

    Reads the just-updated state.yaml: step_history[-1] is the step that just
    recorded, so its duration/tokens/cost render without threading usage back
    through the call sites. Best-effort — a missing or unreadable state file
    never interrupts the loop.
    """
    try:
        with open(state_yaml_path) as f:
            state_raw = yaml.safe_load(f) or {}
    except (OSError, yaml.YAMLError):
        return
    step_usage = format_last_step_usage(state_raw)
    if step_usage:
        _log(f"  {step_usage}")
    _log(format_cost_so_far(state_raw))


def _now_ms() -> int:
    return int(time.time() * 1000)


# ---------------------------------------------------------------------------
# Prompt assembly — faithful port of run-workflow.sh build_prompt()
# ---------------------------------------------------------------------------
def build_prompt(
    instruction: str,
    step_context: str,
    workflow_meta: str,
) -> str:
    """Assemble the agent prompt. Ticket body is not injected here — the
    load-ticket-context workflow step writes
    spec/changes/<id>/ticket-context.md for agents to read.

    `instruction` already carries this step's own learnings.md content, if
    any (parser.load_contract_for_step inlines it — see steps/<id>/learnings.md).
    """
    return (
        f"{instruction}\n\n{workflow_meta}\n\n"
        f"Step context:\n{step_context}\n{_COMPLETION_CONTRACT}\n"
    )


def _workflow_meta(state_raw: dict[str, Any], state_yaml_path: str) -> str:
    """Reproduce state_inspect workflow-meta lines used in the agent prompt."""
    cid = state_raw.get("change_id") or state_raw.get("slug") or Path(state_yaml_path).parent.name
    schema = state_raw.get("schema") or ""
    repo = state_raw.get("repo_root") or ""
    wt = state_raw.get("worktree_path") or ""
    lines = [
        f"Workflow: change_id={cid} schema={schema} repo_root={repo}",
        f"state_yaml_path={state_yaml_path}",
    ]
    if wt:
        lines.append(f"worktree_path={wt}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool invocation — faithful port of run-workflow.sh invoke_tool()
# ---------------------------------------------------------------------------
def _resolve_tool_template(tool_name: str, models_yaml: str | None) -> tuple[str, list[str]]:
    """Return (binary, args_template) for `tool_name`, resolved through the
    layered `tools:` block (D1) — same layer chain/precedence as `models:`.
    """
    return model_routes.resolve_tool_template(tool_name, models_yaml)


def _build_argv(
    tool_name: str, binary: str, template: list[str],
    prompt: str, prompt_file: str, model_id: str,
) -> list[str]:
    def expand(arg: str) -> str:
        if "{prompt_file}" in arg:
            return arg.replace("{prompt_file}", prompt_file)
        if "{model_id}" in arg:
            if not model_id:
                # No silent "auto" default: an unresolved model would run an
                # unknown model and record an unpriceable cost.
                raise ContractDispatchError(
                    f"{tool_name}: no model_id resolved; check the step's "
                    f"model: alias against config/models.yaml"
                )
            return arg.replace("{model_id}", model_id)
        if arg == "{prompt}":
            return prompt
        return str(arg)

    argv = [binary] + [expand(a) for a in template]
    if len(argv) == 1:  # no template
        argv += (["-p", prompt] if tool_name in ("claude", "pi") else [prompt])
    return argv


def invoke_tool(
    tool_name: str, binary: str, template: list[str],
    prompt: str, prompt_file: str, model_id: str,
    cwd: str | None, stdout_path: Path, stderr_path: Path,
    *,
    extra_env: dict[str, str] | None = None,
) -> int:
    argv = _build_argv(tool_name, binary, template, prompt, prompt_file, model_id)
    env = os.environ.copy()
    if extra_env:
        env.update({k: str(v) for k, v in extra_env.items() if v is not None})
    env.setdefault("PI_CODING_AGENT_DIR", str(Path.home() / ".pi" / "agent"))
    run_cwd = cwd if cwd and Path(cwd).is_dir() else None
    with open(stdout_path, "w") as out, open(stderr_path, "w") as err:
        proc = subprocess.run(argv, stdout=out, stderr=err, stdin=subprocess.DEVNULL, cwd=run_cwd, env=env)
    return proc.returncode


# ---------------------------------------------------------------------------
# Agent step execution
# ---------------------------------------------------------------------------
def _failed_payload(action: dict, exit_code: int) -> dict:
    # usage carries model="none" + zero tokens so dispatch._is_spawn_failure
    # counts this toward the spawn-failure cap (quality_bar.max_spawn_failures).
    # Termination of a failing step is handled by record's on_failure routing +
    # retry cap (and, with no routing, a failed node simply isn't re-opened — the
    # phase completes). The spawn-cap shape here is the belt-and-suspenders bound
    # for steps that DO loop via on_failure: without model="none" those retries
    # wouldn't count as spawn failures and could outrun the cap. See
    # test_run_loop_termination.
    return {
        "step_id": action["step_id"],
        "phase": action.get("phase", "main"),
        "status": "failed",
        "agent": action.get("model", ""),
        "outputs": {"task_execution_result": {"status": "failed", "exit_code": exit_code}},
        "usage": {**dict(_EMPTY_USAGE), "model": "none"},
    }


_RESERVED_PAYLOAD_KEYS = frozenset({
    "step_id", "phase", "status", "agent", "agent_id", "attempt",
    "started_at", "usage", "outputs", "evidence", "state_patch",
})


def _agent_payload(action: dict, completion: dict, usage: dict, started_at) -> dict:
    payload = dict(completion)
    payload["step_id"] = action["step_id"]
    payload["phase"] = action.get("phase", "main")
    payload["agent"] = action.get("model", "")
    if not isinstance(payload.get("outputs"), dict):
        payload["outputs"] = {}
    for key in list(payload.keys()):
        if key not in _RESERVED_PAYLOAD_KEYS and key not in payload["outputs"]:
            payload["outputs"][key] = payload.pop(key)
    payload["usage"] = {**dict(_EMPTY_USAGE), **(usage or {})}
    if started_at:
        payload["started_at"] = started_at
    return payload


def run_agent_step(
    action: dict, *, repo_root: str, models_yaml: str,
    state_raw: dict, state_yaml_path: str, tmp_dir: Path,
) -> dict:
    """Execute one agent action; always returns a done-payload dict.

    Failure policy (LOCKED, deviates from bash): tool nonzero exit AND malformed
    COMPLETION both → `failed` payload so on_failure/max_retries retries. A bad
    parse never aborts the workflow.

    Ticket context is not fetched here — load-ticket-context (workflow config)
    writes spec/changes/<id>/ticket-context.md; agent prompts instruct reading that file.
    """
    model = action["model"]
    step_id = action["step_id"]
    started_at = action.get("started_at") or datetime.now(timezone.utc).isoformat()

    # Resolve once (D3): subprocess + model_id must come from the SAME chosen
    # candidate in a fallback chain, never mixed across candidates.
    route = model_routes.resolve_route(model, models_yaml)
    tool_name = route["subprocess"]
    if not tool_name:
        _log(f"ERROR: no route for model '{model}'")
        raise SystemExit(4)
    model_id = route["model_id"]
    binary, template = _resolve_tool_template(tool_name, models_yaml)

    meta = _workflow_meta(state_raw, state_yaml_path)
    step_context = json.dumps(action.get("step_context") or {})
    prompt = build_prompt(action.get("instruction", ""), step_context, meta)
    prompt_file = tmp_dir / f"prompt_{step_id}.txt"
    prompt_file.write_text(prompt)

    work_dir = state_raw.get("worktree_path") or repo_root
    if not Path(work_dir).is_dir():
        work_dir = repo_root

    stdout_path = tmp_dir / f"out_{step_id}.txt"
    stderr_path = tmp_dir / f"err_{step_id}.txt"
    fallback_note = f"  (fallback #{route['active_index']} for {model})" if route["is_fallback"] else ""
    _log(f"  invoking {tool_name} ({binary})" + (f"  model={model_id}" if model_id else "") + fallback_note)
    agent_env = dict(action.get("env") or {})
    prompt_dir = action.get("prompt_dir") or agent_env.get("ORCHESTRATOR_PROMPT_DIR")
    if prompt_dir:
        agent_env["ORCHESTRATOR_PROMPT_DIR"] = str(prompt_dir)
    rc = invoke_tool(tool_name, binary, template, prompt, str(prompt_file),
                     model_id, work_dir, stdout_path, stderr_path,
                     extra_env=agent_env)
    if rc != 0:
        stderr_tail = stderr_path.read_text(errors="replace")[-2000:] if stderr_path.exists() else ""
        _log(f"WARN: tool '{binary}' exited {rc}")
        if stderr_tail.strip():
            _log(f"  stderr: {stderr_tail.strip()}")
        return _failed_payload(action, rc)

    adapter_tool = "cursor-agent" if tool_name == "cursor" else tool_name
    norm = split_stdout(adapter_tool, stdout_path, route_model=model_id or None)
    usage = {k: v for k, v in norm.items() if k != "assistant_text"}
    try:
        completion = parse_completion(norm.get("assistant_text") or "")
    except ValueError as exc:
        # LOCKED policy: malformed COMPLETION is recoverable, not fatal.
        _log(f"WARN: malformed COMPLETION for {step_id} — recording failed (retryable): {exc}")
        return _failed_payload(action, 5)

    return _agent_payload(action, completion, usage, started_at)


# ---------------------------------------------------------------------------
# Script step execution — canonical path (lifted from bin/orchestrator inline
# arm; dead exit-10 soft-fail intentionally NOT carried).
# ---------------------------------------------------------------------------
def run_script_step(action: dict, *, state_yaml_path: str, state=None) -> tuple[bool, str]:
    """Run an inline script step. Returns (ok, new_state_path).

    ok=False  → script exited nonzero AND step has no on_failure routing: the
    workflow must abort (deterministic scripts like merge-to-main / create-worktree
    cannot self-heal by re-dispatch). Matches the old CLI inline arm's exit(3).
    ok=False is returned ONLY when re-dispatch would loop; if the contract has
    on_failure, the failure is recorded and the loop retries (ok=True).

    For archive-completed-change: durable pre-write BEFORE running (state file
    moves), so the entry survives the relocation; returns (True, relocated_path).
    """
    from orchestrator_next.parser import ScriptStepContract, load_contract_for_step
    from orchestrator_next.paths import config_root
    from orchestrator_next.step_env import inline_script_env
    step_id = action["step_id"]
    phase = action.get("phase", "main")
    attempt = action.get("attempt", 1)
    if state is None:
        state = load_state(state_yaml_path)
    contract = load_contract_for_step(step_id)
    if not isinstance(contract, ScriptStepContract):
        raise ContractDispatchError(f"run_script_step called on non-script contract: {step_id}")
    env = inline_script_env(state, state_yaml_path, action_env=action.get("env", {}))
    # parser absolutizes run: relative to the contract dir, so the script's own
    # directory IS the step dir.
    env["ORCHESTRATOR_STEP_DIR"] = os.path.dirname(contract.run)
    _params_path = config_root() / "steps" / step_id / "contract.yaml"
    if _params_path.is_file():
        _raw = yaml.safe_load(_params_path.read_text(encoding="utf-8")) or {}
        for k, v in (_raw.get("params") or {}).items():
            env.setdefault(str(k), str(v))
    if not os.path.isfile(contract.run):
        raise FileNotFoundError(f"step script not found: {contract.run}")
    run_cmd = ["bash", contract.run]

    _log(f"→ {step_id}  phase={phase}  kind=inline script  attempt={attempt}")
    _log(f"  run: {' '.join(run_cmd)}")

    state_mutating = contract.state_mutating
    if state_mutating:
        record(state_yaml_path, {
            "step_id": step_id, "phase": phase, "attempt": attempt,
            "status": "completed", "outputs": {},
            "evidence": {"summary": "recorded pre-script (state-mutating inline step)"},
        })

    cwd = env.get("REPO_ROOT") or None
    if cwd and not os.path.isdir(cwd):
        cwd = None
    # Measure elapsed ms here: record.py's derive-from-timestamps fallback can't
    # serve script steps (started_at would default to ended_at), and _utcnow_iso
    # truncates to whole seconds, flooring sub-second steps to 0.
    _start_ms = _now_ms()
    proc = subprocess.run(run_cmd, capture_output=True, env=env, cwd=cwd)
    script_duration_ms = _now_ms() - _start_ms
    if proc.stderr:
        sys.stderr.buffer.write(proc.stderr)
        sys.stderr.buffer.flush()

    new_state_path = state_yaml_path
    if proc.returncode != 0:
        if not state_mutating:
            record(state_yaml_path, {
                "step_id": step_id, "phase": phase, "attempt": attempt,
                "status": "failed", "outputs": {},
                "usage": {"duration_ms": script_duration_ms},
                "evidence": {"summary": f"script exited {proc.returncode}"},
            })
        _log(f"✗ {step_id}  failed  script_exit={proc.returncode}")
        # No script step carries on_failure routing (every on_failure source/
        # target in the schemas is an agent step). A failed deterministic script
        # can't self-heal via re-dispatch, so abort — matches the old CLI inline
        # arm's sys.exit(3). ok=False signals the loop to stop.
        return False, new_state_path

    outputs = _parse_stdout_outputs(proc)
    if not state_mutating:
        payload = {
            "step_id": step_id, "phase": phase, "attempt": attempt,
            "status": "completed", "outputs": outputs,
            "usage": {"duration_ms": script_duration_ms},
            "evidence": {"outputs": outputs, "summary": "inline script completed"},
        }
        if isinstance(outputs.get("state_patch"), dict):
            payload["state_patch"] = outputs["state_patch"]
        record(state_yaml_path, payload)
    # Relocate state path if the script moved it (archive-completed-change emits
    # archive_record.archive_path when it succeeds).
    new_state_path = _relocate_after_archive(outputs, new_state_path)

    _log(f"✓ {step_id}  done  status=completed")
    _log_cost_so_far(new_state_path)
    return True, new_state_path


def _parse_stdout_outputs(proc) -> dict:
    """Parse the last JSON line of script stdout into an outputs dict."""
    lines = proc.stdout.decode(errors="replace").strip().splitlines()
    if lines:
        try:
            return json.loads(lines[-1])
        except (json.JSONDecodeError, ValueError):
            pass
    return {}


def _relocate_after_archive(outputs, default) -> str:
    """Relocate state path when a script emits archive_record.archive_path."""
    archive_path = (outputs.get("archive_record") or {}).get("archive_path") or ""
    if not archive_path:
        return default
    repo_root = os.environ.get("REPO_ROOT", "")
    candidate = os.path.join(repo_root, archive_path, "state.yaml")
    if os.path.isfile(candidate):
        _log(f"  state relocated: {candidate}")
        return candidate
    return default


# ---------------------------------------------------------------------------
# Exit-2 notification — unattended runs need a human channel for signoffs
# ---------------------------------------------------------------------------
def _notify_blocked(state_yaml_path: str, state_raw: dict[str, Any], reason: str) -> None:
    """Pipe a JSON blocked-event to ORCHESTRATOR_NOTIFY_CMD (stdin), if set.

    Channel-agnostic: point the env var at curl / a Slack CLI / anything.
    Best-effort — a failing notifier never changes the exit code.
    """
    cmd = os.environ.get("ORCHESTRATOR_NOTIFY_CMD", "")
    if not cmd:
        return
    schema = state_raw.get("schema")
    if isinstance(schema, dict):
        schema = schema.get("type")
    payload = json.dumps({
        "event": "blocked",
        "change_id": state_raw.get("change_id") or Path(state_yaml_path).parent.name,
        "schema": schema or "",
        "reason": reason,
        "state_yaml_path": state_yaml_path,
    })
    try:
        subprocess.run(["bash", "-c", cmd], input=payload, text=True,
                       capture_output=True, timeout=30)
    except Exception as exc:  # noqa: BLE001 — notification is best-effort
        _log(f"WARN: notify command failed: {exc}")


# ---------------------------------------------------------------------------
# The loop
# ---------------------------------------------------------------------------
def run_loop(state_yaml_path: str, *, repo_root: str, models_yaml: str) -> int:
    import tempfile
    tmp_dir = Path(tempfile.mkdtemp())
    try:
        # Operator rerun cleanup (spawn_failure_cap), as bash did on entry.
        try:
            from orchestrator_next.spawn_resume import apply_spawn_failure_resume
            apply_spawn_failure_resume(state_yaml_path)
        except Exception:
            pass

        while True:
            if not os.path.isfile(state_yaml_path):
                _log("Workflow complete (state archived).")
                return 1
            state = load_state(state_yaml_path)
            try:
                action, code = dispatch(state, state_yaml_path)
            except (ContractDispatchError, ContractNotFoundError, ContractError) as exc:
                _log(f"Contract error: {exc}")
                return 3
            if code == 1:
                _log("Workflow complete.")
                return 1
            if code == 2:
                _log("Workflow blocked.")
                autocommit_state(state_yaml_path, push=True)
                _notify_blocked(state_yaml_path, state.raw,
                                (action or {}).get("reason") or "blocked (signoff or halt)")
                return 2

            if action.get("model"):
                _log(f"→ {action['step_id']}  phase={action.get('phase','main')}  "
                     f"kind=agent  model={action['model']}  attempt={action.get('attempt',1)}")
                payload = run_agent_step(
                    action, repo_root=repo_root, models_yaml=models_yaml,
                    state_raw=state.raw,
                    state_yaml_path=state_yaml_path, tmp_dir=tmp_dir,
                )
                result, rc = record(state_yaml_path, payload)
                if rc == 3:
                    # bad payload shape → record as failed (retryable), not fatal.
                    _log(f"WARN: record rejected payload for {action['step_id']} — recording failed")
                    record(state_yaml_path, _failed_payload(action, 3))
                else:
                    _log(f"✓ {action['step_id']}  done  status={payload.get('status','completed')}")
                    _log_cost_so_far(state_yaml_path)
            elif action.get("run"):
                ok, state_yaml_path = run_script_step(action, state_yaml_path=state_yaml_path, state=state)
                if not ok:
                    _log("Workflow aborted: deterministic script step failed.")
                    autocommit_state(state_yaml_path, push=True)
                    return 3
            else:
                _log("dispatch returned no actionable step; continuing")
    finally:
        import shutil
        shutil.rmtree(tmp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# `orchestrator run` entry — arg parse + seeding + loop (replaces both shells)
# ---------------------------------------------------------------------------
_AGENT_ROUTE_RE = re.compile(r"^agent\.[a-zA-Z0-9_-]+\.(subprocess|model)=")


def _build_route_overrides(flags: list[str]) -> str:
    data: dict[str, dict[str, str]] = {}
    pat = re.compile(r"agent\.([a-zA-Z0-9_-]+)\.(subprocess|model)=(.+)")
    for flag in flags:
        m = pat.fullmatch(flag)
        if m:
            data.setdefault(m.group(1), {})[m.group(2)] = m.group(3)
    return json.dumps(data)


def _resolve_active_state(slug: str, schema: str, repo_root: str) -> str:
    """Newest active `.orchestrator/<slug>/*_<schema>_state.yaml`, or "" if none.

    Resolving (not seeding) is what makes a re-run RESUME an in-flight workflow
    instead of seeding a second state file. Mirrors orchestrator-run.sh
    resolve_state_yaml.
    """
    state_dir = Path(repo_root) / ".orchestrator" / slug
    matches = sorted(state_dir.glob(f"*_{schema}_state.yaml"))
    return str(matches[-1]) if matches else ""


def _resolve_archived_state(slug: str, repo_root: str) -> str:
    """Archived state under spec/changes/archive/ for an already-completed
    feature, or "" if none. Used by `complete` teardown when the active state
    was already archived. Mirrors orchestrator-run.sh resolve_archived_state_yaml.
    """
    archive = Path(repo_root) / "spec" / "changes" / "archive"
    direct = archive / slug / "state.yaml"
    if direct.is_file():
        return str(direct)
    for dated in sorted(archive.glob(f"*-{slug}/state.yaml")):
        if dated.is_file():
            return str(dated)
    return ""


def _write_initial_state(
    state_yaml: Path, *, slug: str, schema: str, repo_root: str,
    active: list[str], prior_path: str,
) -> None:
    """Write the initial state.yaml, carrying identity fields from the most
    recent prior state file when provided."""
    prior_context: dict = {}
    if prior_path:
        try:
            prior_raw = yaml.safe_load(Path(prior_path).read_text()) or {}
            for key in ("worktree_path", "branch", "repo_root", "change_id", "slug",
                        "ticket_id"):
                if prior_raw.get(key):
                    prior_context[key] = prior_raw[key]
        except (OSError, yaml.YAMLError):
            pass  # prior unreadable — start fresh

    repo_root = prior_context.get("repo_root") or repo_root

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    slug = prior_context.get("slug") or slug
    state = {
        "change_id": prior_context.get("change_id") or slug,
        "slug": slug,
        "ticket_id": prior_context.get("ticket_id") or slug,
        "schema": schema,
        "status": "active",
        "repo_root": repo_root,
        "workflow_plan": {"main": {"active": active, "filtered": []}},
        "phase": "main",
        "next_step": {"phase": "main", "step_id": active[0]},
        "step_history": [],
        "created_at": now,
        "started_at": now,
    }
    if prior_context.get("worktree_path"):
        state["worktree_path"] = prior_context["worktree_path"]
    if prior_context.get("branch"):
        state["branch"] = prior_context["branch"]

    state_yaml.write_text(yaml.safe_dump(state, sort_keys=False, allow_unicode=True))
    _log(f"seeded: {state_yaml}")


def _seed_state(slug: str, schema: str, repo_root: str) -> str:
    """Seed a state file; return its path.
    Idempotent: reuse the newest *_<schema>_state.yaml if present."""
    from orchestrator_next.paths import config_root
    schema_yaml = config_root() / "workflows" / f"{schema}.yaml"
    repo_override = Path(repo_root) / ".orchestrator" / "workflows" / f"{schema}.yaml"
    if repo_override.is_file():
        schema_yaml = repo_override
    if not schema_yaml.is_file():
        _log(f"ERROR: schema '{schema}' not found: {schema_yaml}")
        raise SystemExit(7)

    state_dir = Path(repo_root) / ".orchestrator" / slug
    existing = sorted(state_dir.glob(f"*_{schema}_state.yaml"))
    if existing:
        _log(f"state file exists at {existing[-1]} (idempotent skip)")
        return str(existing[-1])

    # The steps list IS the plan — no gate-filtering (ORC-108).
    from orchestrator_next.workflow_steps import step_id_of

    schema_doc = yaml.safe_load(schema_yaml.read_text()) or {}
    active = [
        sid
        for entry in schema_doc.get("steps", [])
        if (sid := step_id_of(entry))
    ]
    if not active:
        _log(f"ERROR: schema '{schema}' declares no steps")
        raise SystemExit(1)

    state_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    state_yaml = state_dir / f"{timestamp}_{schema}_state.yaml"
    prior = sorted(state_dir.glob("*_state.yaml"))
    prior_path = str(prior[-1]) if prior else ""

    _write_initial_state(state_yaml, slug=slug, schema=schema,
                         repo_root=repo_root, active=active, prior_path=prior_path)

    from orchestrator_next import generate_plan as _gp
    try:
        _gp.generate_plan(str(state_yaml))
    except Exception as exc:
        state_yaml.unlink(missing_ok=True)
        _log(f"error: generate_plan failed: {exc}")
        raise SystemExit(2)

    _log(f"init-workflow: {slug} ({schema}) ready at {state_yaml}")
    return str(state_yaml)


def run_cmd(argv: list[str]) -> int:
    """`orchestrator run <ticket> [--schema S] [--repo P] [flag=value ...]`."""
    ticket_id = ""
    schema = "feature"
    repo_arg = ""
    seed_only = False
    flag_overrides: list[str] = []
    agent_route_flags: list[str] = []
    agents_config_arg = ""
    routes_override_arg = ""

    args = list(argv)
    while args:
        a = args.pop(0)
        if a == "--schema":
            schema = args.pop(0)
        elif a == "--repo":
            repo_arg = args.pop(0)
        elif a == "--agents-config":
            agents_config_arg = args.pop(0)
        elif a == "--routes-override":
            routes_override_arg = args.pop(0)
        elif a == "--seed-only":
            # Seed state.yaml and stop — do NOT drive. For external drivers (e.g. a
            # Claude Code cloud session) that walk next/done themselves instead of
            # letting the engine spawn per-step subprocesses. See DRIVE.md.
            seed_only = True
        elif a in ("--help", "-h"):
            _log("Usage: orchestrator run <ticket-id> [--schema S] [--repo PATH] [--seed-only] [flag=value ...]")
            return 7
        elif a.startswith("-"):
            _log(f"ERROR: unknown option: {a}")
            return 7
        elif not ticket_id:
            ticket_id = a
        elif "=" in a:
            if _AGENT_ROUTE_RE.match(a):
                agent_route_flags.append(a)
            elif a.startswith("agents.config="):
                agents_config_arg = a[len("agents.config="):]
            else:
                flag_overrides.append(a)
        else:
            _log(f"ERROR: unexpected argument: {a}")
            return 7
    if not ticket_id:
        _log("Usage: orchestrator run <ticket-id> [--schema S] ...")
        return 7

    # No repo-side marker file required — any git repo (or cwd) is runnable;
    # ticketing and conventions are env-/docs-driven.
    repo_root = os.path.abspath(repo_arg) if repo_arg else os.environ.get("REPO_ROOT", "")
    if not repo_root:
        try:
            repo_root = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True
            ).stdout.strip() or os.getcwd()
        except Exception:
            repo_root = os.getcwd()
    os.environ["REPO_ROOT"] = repo_root

    # Route-override env (model_routes.py reads these from os.environ).
    if routes_override_arg:
        os.environ["ORCHESTRATOR_ROUTES_YAML"] = os.path.abspath(routes_override_arg)
    if agents_config_arg:
        os.environ["ORCHESTRATOR_MODELS_CONFIG"] = os.path.abspath(agents_config_arg)
    if agent_route_flags:
        os.environ["ORCHESTRATOR_MODEL_ROUTE_OVERRIDES"] = _build_route_overrides(agent_route_flags)

    slug = ticket_id.lower()

    # State resolution (mirrors orchestrator-run.sh): resolve an existing state
    # BEFORE seeding, so a re-run resumes instead of seeding a duplicate. `complete`
    # is a separate teardown workflow that must NOT be driven from a feature state
    # whose DAG is exhausted — resolve its own *_complete_state.yaml, and if the
    # feature was already archived, resolve the archived state for merge/teardown.
    state_yaml_path = _resolve_active_state(slug, schema, repo_root)
    if not state_yaml_path and schema == "complete":
        state_yaml_path = _resolve_archived_state(slug, repo_root)
        if state_yaml_path:
            _log(f"Resuming complete on archived state: {state_yaml_path}")
    if not state_yaml_path:
        state_yaml_path = _seed_state(slug, schema, repo_root)

    # --seed-only: stop here. The caller (external driver) walks next/done itself.
    # Print the path on its own final line so callers can `tail -1` it.
    if seed_only:
        _log(f"seeded (seed-only): {state_yaml_path}")
        print(state_yaml_path)
        return 0

    # models.yaml resolution (override > repo > global), mirrors run-workflow.sh.
    models_yaml = os.environ.get("ORCHESTRATOR_MODELS_CONFIG", "")
    if not models_yaml:
        from orchestrator_next.paths import config_root
        for cand in (
            Path(repo_root) / ".orchestrator" / "config" / "models.yaml",
            Path(repo_root) / "config" / "models.yaml",
            config_root() / "models.yaml",
        ):
            if cand.is_file():
                models_yaml = str(cand)
                break

    _log(f"Running workflow: ticket={ticket_id} schema={schema} state={state_yaml_path}")
    return run_loop(state_yaml_path, repo_root=repo_root, models_yaml=models_yaml)


if __name__ == "__main__":
    sys.exit(run_cmd(sys.argv[1:]))
